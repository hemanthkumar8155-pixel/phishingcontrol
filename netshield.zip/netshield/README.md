# NetShield – Network-Based Website Risk Analysis and QR Phishing Detection

NetShield checks a link, or a QR code that contains a link, **without ever opening it**. It combines offline URL analysis with live network lookups (DNS and domain registration records) and produces a 0–100 risk score with a plain-language explanation of every warning sign.

The whole front end is static, so it runs on **GitHub Pages** with no server. An optional Python backend adds redirect-chain and TLS-certificate inspection.

## Features

| Area | What it does |
|---|---|
| URL analysis | Flags HTTP, IP-address hosts, `user@host` tricks, look-alike (homograph) characters, punycode, nested subdomains, hyphen-heavy names, risky endings (`.tk`, `.zip`…), link shorteners, redirect parameters, pressure words (`verify`, `kyc`, `otp`…) |
| Brand impersonation | Detects a brand name on an unrelated domain (`paypal.com.evil.tk`) and typo/leet look-alikes (`paypa1.com`) using edit distance |
| Network checks | DNS over HTTPS (Cloudflare): resolution, private-IP answers, short TTL, name servers. RDAP: domain age and registrar |
| QR codes | Upload an image, drag and drop, or scan with the camera. Decodes with jsQR, then classifies the payload: web link, `javascript:`, `data:`, UPI payment, Wi-Fi join, call/text/email |
| Optional backend | Follows redirects hop by hop, validates the TLS certificate, checks HSTS/CSP headers, blocks internal addresses |
| Safe output | All scanned content is rendered as text (never HTML), so a malicious QR code cannot inject script into the page |

## Project structure

```
netshield/
├── README.md
├── LICENSE
├── .gitignore
├── .github/workflows/deploy-pages.yml   # tests, then deploys docs/ to GitHub Pages
├── docs/                                # the static site (GitHub Pages root)
│   ├── index.html
│   ├── .nojekyll
│   ├── css/style.css
│   └── js/
│       ├── app.js                       # UI wiring and rendering
│       ├── analyzer.js                  # URL heuristics and scoring
│       ├── network.js                   # DNS-over-HTTPS, RDAP, backend client
│       └── qr.js                        # QR decoding and payload classification
├── backend/                             # optional deep-scan API
│   ├── app.py
│   └── requirements.txt
└── tests/analyzer.test.mjs              # Node built-in test runner
```

## How it works

```
 link or QR image ──► qr.js ──► classifyPayload ─┐
                                                 ▼
                                   analyzer.js (offline heuristics)
                                                 │
        ┌────────────────────────────────────────┼───────────────────────────┐
        ▼                                        ▼                           ▼
 DNS over HTTPS (Cloudflare)             RDAP (domain age)        optional backend (redirects, TLS)
        └────────────────────────────────────────┼───────────────────────────┘
                                                 ▼
                              scoreFindings ──► risk ruler + findings list
```

Each finding carries points. The total is capped at 100:

| Score | Verdict |
|---|---|
| 0–19 | Low risk |
| 20–44 | Suspicious |
| 45–69 | Likely phishing |
| 70–100 | Dangerous |

Weights live in `docs/js/analyzer.js` and `docs/js/network.js`; adjust them to tune sensitivity.

## Run locally

No build step is needed.

```bash
cd netshield
python3 -m http.server 8000 --directory docs
# open http://localhost:8000
```

Run the tests (Node 18+):

```bash
node --test tests/*.test.mjs
```

### Optional backend

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py                                         # http://localhost:5000
```

Then open the **Deeper scan** section on the page and enter `http://localhost:5000`.

For a hosted backend use `gunicorn app:app`, serve it over HTTPS (a Pages site cannot call plain-HTTP servers other than localhost), and restrict who can call it:

```bash
ALLOWED_ORIGIN=https://<your-username>.github.io gunicorn app:app
```

## Deploy to GitHub Pages

### Option A – GitHub Actions (recommended)

1. Create an empty repository on GitHub (for example `netshield`).
2. Push this project:

   ```bash
   cd netshield
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/netshield.git
   git push -u origin main
   ```

3. In the repository go to **Settings → Pages**. Under **Build and deployment**, set **Source** to **GitHub Actions**.
4. Open the **Actions** tab. The *Deploy to GitHub Pages* workflow runs the tests, then publishes `docs/`. Re-run it from the tab if it started before you changed the setting.
5. Your site appears at `https://<your-username>.github.io/netshield/` (the link is also shown on the workflow run).

Every push to `main` redeploys automatically.

### Option B – Deploy from a branch (no Actions)

1. Push the project as above.
2. Go to **Settings → Pages**, set **Source** to **Deploy from a branch**, choose branch `main` and folder `/docs`, then **Save**.
3. Delete `.github/workflows/deploy-pages.yml` so the two methods do not conflict.

### Troubleshooting

- **404 after deploying:** wait a minute, then check that the Pages source matches the option you used.
- **Camera does not start:** browsers only allow it on HTTPS or `localhost`. Pages is HTTPS, but you must allow camera permission. Uploading an image always works.
- **"unavailable" next to DNS or Domain age:** the lookup service was unreachable, blocked by an extension or network, or does not publish CORS headers for that registry. Other checks still run.
- **jsQR does not load (offline or restricted network):** download `jsQR.min.js` into `docs/js/vendor/` and change the `<script>` tag in `docs/index.html` to point to it.

## Privacy and security notes

- Typed or scanned links are **not** sent to any server of ours. The browser sends the domain name to Cloudflare (DNS over HTTPS) and `rdap.org` (domain registration). If you configure a backend, the full link goes to that backend.
- The backend resolves every hop and refuses non-public addresses and ports other than 80 and 443. It cannot fully prevent DNS rebinding between its check and the HTTP request; run it in an isolated environment and add rate limiting (for example Flask-Limiter) before exposing it publicly.
- Heuristics produce false positives and false negatives. A low score is not proof of safety, and a brand allow-list in `analyzer.js` only covers a small set of well-known domains.

## Ideas for extension

- Add Google Safe Browsing or PhishTank lookups in the backend (these need API keys, so keep them server-side).
- Check Certificate Transparency logs for newly issued certificates.
- Detect QR "quishing" overlays by comparing the decoded domain with the sender's domain in a screenshot.

## Licence

MIT. See `LICENSE`.
