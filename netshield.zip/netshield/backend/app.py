"""Optional deep-scan backend for NetShield.

Follows redirects (without trusting them), reads the TLS certificate and checks
a few security headers. It refuses to contact private or internal addresses so
it cannot be used as a proxy into your own network (SSRF protection).
"""
import ipaddress
import os
import socket
import ssl
import time
from urllib.parse import urljoin, urlparse

import requests
from flask import Flask, jsonify, request

app = Flask(__name__)
MAX_HOPS = 8
TIMEOUT = 6
HEADERS = {"User-Agent": "NetShield/1.0 (link safety checker)"}


@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = os.environ.get("ALLOWED_ORIGIN", "*")
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return resp


def resolve_public(host: str) -> str:
    """Return a public IP for `host`, or raise ValueError."""
    try:
        ips = {info[4][0] for info in socket.getaddrinfo(host, None)}
    except socket.gaierror:
        raise ValueError(f"Cannot resolve {host}")
    if not all(ipaddress.ip_address(ip).is_global for ip in ips):
        raise ValueError("Refusing to contact a non-public address")
    return sorted(ips)[0]


def follow(url: str):
    """Follow redirects manually, vetting every hop. Returns (hops, final_url, ip, response)."""
    hops = []
    for _ in range(MAX_HOPS + 1):
        parts = urlparse(url)
        if parts.scheme not in ("http", "https") or not parts.hostname:
            raise ValueError("Unsupported address")
        if parts.port not in (None, 80, 443):
            raise ValueError("Only ports 80 and 443 are allowed")
        ip = resolve_public(parts.hostname)
        resp = requests.get(url, allow_redirects=False, stream=True, timeout=TIMEOUT, headers=HEADERS)
        resp.close()
        hops.append({"url": url, "status": resp.status_code})
        location = resp.headers.get("Location")
        if resp.is_redirect and location:
            url = urljoin(url, location)
            continue
        return hops, url, ip, resp
    raise ValueError("Too many redirects")


def tls_info(ip: str, host: str, port: int = 443) -> dict:
    """Validate the certificate by connecting to the vetted IP with the real hostname."""
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((ip, port), timeout=TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as tls:
                cert = tls.getpeercert()
    except ssl.SSLCertVerificationError as exc:
        return {"valid": False, "error": exc.verify_message}
    except (OSError, ssl.SSLError) as exc:
        return {"valid": False, "error": str(exc)[:160]}
    issuer = dict(item[0] for item in cert["issuer"])
    days_left = int((ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) // 86400)
    return {
        "valid": True,
        "issuer": issuer.get("organizationName") or issuer.get("commonName", "unknown"),
        "days_left": days_left,
    }


@app.get("/api/health")
def health():
    return jsonify({"ok": True})


@app.get("/api/analyze")
def analyze():
    url = request.args.get("url", "")
    try:
        hops, final_url, ip, resp = follow(url)
    except ValueError as exc:
        return jsonify({"error": str(exc)})
    except requests.RequestException:
        return jsonify({"error": "Could not reach the site."})

    host = urlparse(final_url).hostname
    return jsonify({
        "redirects": hops,
        "final_url": final_url,
        "ip": ip,
        "tls": tls_info(ip, host) if final_url.startswith("https") else None,
        "security_headers": {
            "hsts": "strict-transport-security" in resp.headers,
            "csp": "content-security-policy" in resp.headers,
        },
    })


if __name__ == "__main__":
    app.run(port=int(os.environ.get("PORT", 5000)))
