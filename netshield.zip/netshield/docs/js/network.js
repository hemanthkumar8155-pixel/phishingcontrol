// Network-based checks: DNS over HTTPS, RDAP domain age, and the optional backend.
import { finding as f, registrableDomain } from './analyzer.js';

async function getJson(url, headers = {}, ms = 7000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(url, { headers, signal: ctl.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } finally { clearTimeout(timer); }
}

const doh = (name, type) =>
  getJson(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`, { accept: 'application/dns-json' });
const isPrivateIp = (ip) => /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);

export async function dnsProfile(host, domain) {
  const findings = [], facts = [];
  const [a, ns] = await Promise.all([doh(host, 'A'), doh(domain, 'NS')]);
  const ips = (a.Answer || []).filter((r) => r.type === 1);

  if (a.Status === 3) findings.push(f('nxdomain', 20, 'Domain does not exist in DNS', 'The site may have been taken down, or the address is mistyped or fake.'));
  if (ips.some((r) => isPrivateIp(r.data))) findings.push(f('private-ip', 25, 'Domain points to a private network address', 'Public sites should not resolve to internal addresses; this can be used to attack devices on your network.'));
  facts.push(['IPv4 addresses', ips.map((r) => r.data).join(', ') || 'none']);
  if (ips.length) {
    const ttl = Math.min(...ips.map((r) => r.TTL));
    facts.push(['DNS cache time', `${ttl}s`]);
    if (ttl < 120) findings.push(f('low-ttl', 6, 'Very short DNS cache time', 'Short TTLs let attackers move a site between servers quickly.'));
  }
  facts.push(['Name servers', (ns.Answer || []).filter((r) => r.type === 2).map((r) => r.data).join(', ') || 'none returned']);
  return { findings, facts };
}

export async function domainAge(domain) {
  const findings = [], facts = [];
  const d = await getJson(`https://rdap.org/domain/${encodeURIComponent(domain)}`, {}, 9000);
  const when = (action) => (d.events || []).find((e) => e.eventAction === action)?.eventDate;
  const reg = when('registration');
  const registrar = (d.entities || []).find((e) => (e.roles || []).includes('registrar'))
    ?.vcardArray?.[1]?.find((x) => x[0] === 'fn')?.[3];
  if (registrar) facts.push(['Registrar', registrar]);
  if (when('expiration')) facts.push(['Registration expires', when('expiration').slice(0, 10)]);
  if (reg) {
    const days = Math.floor((Date.now() - new Date(reg)) / 864e5);
    facts.push(['Domain registered', `${reg.slice(0, 10)} (${days} days ago)`]);
    if (days < 30) findings.push(f('age', 30, 'Domain registered in the last 30 days', 'Most phishing domains are used within days of registration.'));
    else if (days < 180) findings.push(f('age', 15, 'Domain is less than 6 months old', 'Newly registered domains deserve extra caution.'));
    else if (days < 365) findings.push(f('age', 5, 'Domain is less than a year old', 'Not suspicious on its own.'));
  } else facts.push(['Domain registered', 'date not published']);
  return { findings, facts };
}

export async function deepScan(url, backend) {
  if (!backend) return { findings: [], facts: [] };
  const d = await getJson(`${backend.replace(/\/$/, '')}/api/analyze?url=${encodeURIComponent(url)}`, {}, 20000);
  if (d.error) return { findings: [f('deep-error', 0, 'Deep scan could not finish', d.error)], facts: [] };

  const findings = [], facts = [];
  const hops = d.redirects.length - 1;
  facts.push(['Server IP', d.ip || 'unknown'], ['Redirect hops', String(hops)], ['Final address', d.final_url]);
  if (hops >= 4) findings.push(f('hops', 10, `Passes through ${hops} redirects`, d.redirects.map((r) => r.url).join(' → ')));
  try {
    const from = registrableDomain(new URL(url).hostname), to = registrableDomain(new URL(d.final_url).hostname);
    if (from !== to) findings.push(f('cross-domain', 12, 'Ends up on a different domain', `${from} → ${to}`));
  } catch { /* ignore malformed final URL */ }
  if (d.tls) {
    if (!d.tls.valid) findings.push(f('tls-invalid', 25, 'Certificate failed verification', d.tls.error || 'The HTTPS certificate is not trusted.'));
    else {
      facts.push(['Certificate issuer', d.tls.issuer], ['Certificate expires in', `${d.tls.days_left} days`]);
      if (d.tls.days_left < 7) findings.push(f('tls-expiry', 8, 'Certificate expires within a week', 'Poorly maintained or throwaway site.'));
    }
  }
  facts.push(['HSTS header', d.security_headers?.hsts ? 'present' : 'missing']);
  return { findings, facts };
}
