import { analyzeUrl, scoreFindings } from './analyzer.js';
import { dnsProfile, domainAge, deepScan } from './network.js';
import { decodeFile, startCamera, classifyPayload } from './qr.js';

const $ = (s) => document.querySelector(s);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text; // textContent only: scanned data is untrusted
  return n;
};
const status = (m) => { $('#status').textContent = m; };

const KEY = 'netshield.backend';
const backend = () => { try { return localStorage.getItem(KEY) || ''; } catch { return ''; } };
$('#backend-url').value = backend();
$('#backend-url').addEventListener('change', (e) => {
  try { localStorage.setItem(KEY, e.target.value.trim()); } catch { /* storage unavailable */ }
});

function render(target, findings, facts) {
  const { score, level, label, advice } = scoreFindings(findings);
  const result = $('#result');
  result.hidden = false;
  result.dataset.level = level;
  $('#ruler').style.setProperty('--pct', score);
  $('#score').textContent = score;
  $('#target').textContent = target;
  $('#level').textContent = label;
  $('#summary').textContent = advice;

  const ul = $('#findings');
  ul.replaceChildren();
  if (!findings.length) ul.append(el('li', 'empty', 'No warning signs found in the address or its records.'));
  [...findings].sort((a, b) => b.points - a.points).forEach((x) => {
    const li = el('li', x.points >= 25 ? 'high' : x.points >= 10 ? 'med' : x.points > 0 ? 'low' : '');
    const body = el('div');
    body.append(el('strong', '', x.title), el('p', '', x.detail));
    li.append(el('span', 'pts', x.points ? `+${x.points}` : 'info'), body);
    ul.append(li);
  });

  const dl = $('#facts');
  dl.replaceChildren();
  facts.forEach(([k, v]) => dl.append(el('dt', '', k), el('dd', '', v)));
  result.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function run(input, source) {
  stopCamera();
  status('Analyzing…');
  const payload = classifyPayload(input);
  const findings = [...payload.findings];
  const facts = [['Source', source], ['Content type', payload.kind]];

  if (payload.url) {
    const a = analyzeUrl(payload.url);
    if (a.error) return status(a.error);
    findings.push(...a.findings);
    facts.push(['Host', a.host], ['Registrable domain', a.domain]);

    status('Looking up DNS and registration records…');
    const jobs = [['Deep scan', deepScan(a.url, backend())]];
    if (!a.isIp) jobs.push(['DNS', dnsProfile(a.host, a.domain)], ['Domain age', domainAge(a.domain)]);
    const results = await Promise.allSettled(jobs.map((j) => j[1]));
    results.forEach((r, i) => {
      if (r.status === 'fulfilled') { findings.push(...r.value.findings); facts.push(...r.value.facts); }
      else facts.push([jobs[i][0], `unavailable (${r.reason?.message || 'request failed'})`]);
    });
  }
  render(payload.url || input, findings, facts);
  status('Done. The link was not opened.');
}

// ---- Tabs
document.querySelectorAll('.tab').forEach((tab) => tab.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach((t) => t.setAttribute('aria-selected', t === tab));
  $('#pane-url').hidden = tab.dataset.tab !== 'url';
  $('#pane-qr').hidden = tab.dataset.tab !== 'qr';
  if (tab.dataset.tab !== 'qr') stopCamera();
}));

// ---- URL input
$('#url-form').addEventListener('submit', (e) => { e.preventDefault(); run($('#url-input').value, 'Typed link'); });
document.querySelectorAll('[data-sample]').forEach((b) => b.addEventListener('click', () => {
  $('#url-input').value = b.dataset.sample;
  run(b.dataset.sample, 'Example link');
}));

// ---- QR input
async function handleFile(file) {
  if (!file) return;
  status('Reading QR code…');
  let text = null;
  try { text = await decodeFile(file); } catch { /* unreadable image */ }
  if (!text) return status('No QR code found. Try a sharper, closer image with the whole code visible.');
  run(text, 'QR code image');
}
$('#qr-file').addEventListener('change', (e) => handleFile(e.target.files[0]));
const drop = $('#drop');
['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', (e) => handleFile(e.dataTransfer.files[0]));

let stopCam = null;
function stopCamera() {
  if (stopCam) { stopCam(); stopCam = null; }
  $('#cam-btn').textContent = 'Scan with camera';
}
$('#cam-btn').addEventListener('click', async () => {
  if (stopCam) return stopCamera();
  try {
    stopCam = await startCamera($('#cam'), (text) => { stopCam = null; run(text, 'QR code (camera)'); });
    $('#cam-btn').textContent = 'Stop camera';
    status('Point the camera at a QR code.');
  } catch { status('Camera unavailable. Allow camera access, or upload an image instead.'); }
});
