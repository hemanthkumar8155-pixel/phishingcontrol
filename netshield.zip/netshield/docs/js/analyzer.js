// Lexical URL analysis: every check here runs offline in the browser.

export const finding = (id, points, title, detail) => ({ id, points, title, detail });

const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;
const BRANDS = ['paypal', 'google', 'microsoft', 'apple', 'amazon', 'facebook', 'instagram', 'netflix', 'whatsapp',
  'paytm', 'phonepe', 'sbi', 'hdfc', 'icici', 'axis', 'irctc', 'binance', 'coinbase', 'dropbox', 'linkedin', 'outlook'];
const OFFICIAL = new Set(['google.com', 'googleusercontent.com', 'microsoft.com', 'microsoftonline.com', 'live.com',
  'apple.com', 'icloud.com', 'amazon.com', 'amazon.in', 'paypal.com', 'facebook.com', 'instagram.com', 'whatsapp.com',
  'netflix.com', 'linkedin.com', 'sbi.co.in', 'hdfcbank.com', 'icicibank.com', 'axisbank.com', 'irctc.co.in',
  'paytm.com', 'phonepe.com']);
const SHORTENERS = new Set(['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly', 'rebrand.ly',
  'cutt.ly', 'shorturl.at', 'qrco.de', 'tiny.cc']);
const RISKY_TLDS = new Set(['zip', 'mov', 'tk', 'ml', 'ga', 'cf', 'gq', 'top', 'xyz', 'click', 'link', 'rest', 'icu',
  'buzz', 'cam', 'support', 'work']);
const KEYWORDS = ['login', 'signin', 'verify', 'secure', 'account', 'update', 'banking', 'wallet', 'password',
  'confirm', 'suspend', 'unlock', 'invoice', 'payment', 'refund', 'kyc', 'otp', 'reward', 'prize', 'gift'];
const MULTI_TLDS = new Set(['co.uk', 'org.uk', 'com.au', 'co.in', 'net.in', 'org.in', 'gov.in', 'ac.in', 'co.jp',
  'com.br', 'co.za', 'com.cn']);

export function registrableDomain(host) {
  if (IPV4.test(host) || host.includes(':')) return host;
  const parts = host.split('.');
  if (parts.length <= 2) return host;
  const last2 = parts.slice(-2).join('.');
  return MULTI_TLDS.has(last2) ? parts.slice(-3).join('.') : last2;
}

function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
const deLeet = (s) => s.replace(/rn/g, 'm').replace(/[01358]/g, (c) => ({ 0: 'o', 1: 'l', 3: 'e', 5: 's', 8: 'b' }[c]));

export function analyzeUrl(raw) {
  const findings = [];
  const add = (...a) => findings.push(finding(...a));
  let u;
  try { u = new URL(raw); } catch { return { error: 'That does not look like a valid link.', findings }; }
  if (!/^https?:$/.test(u.protocol)) return { error: `Unsupported scheme: ${u.protocol}`, findings };

  const host = u.hostname.toLowerCase().replace(/\.$/, '');
  const isIp = IPV4.test(host) || host.startsWith('[');
  const domain = registrableDomain(host);
  const sld = domain.split('.')[0];
  const tld = host.split('.').pop();
  const rawHost = raw.split('/')[2] || '';

  if (u.protocol === 'http:') add('http', 15, 'No encryption (HTTP)', 'Anything typed on this page, including passwords, can be read in transit.');
  if (isIp) add('ip-host', 25, 'Address is a bare IP number', 'Legitimate services almost always use a domain name.');
  if (u.username || u.password) add('userinfo', 25, 'Text before "@" hides the real host', `The browser will actually connect to "${host}", not to what appears before the @.`);
  if (/[^\x00-\x7F]/.test(rawHost)) add('homograph', 25, 'Look-alike characters in the domain', 'Non-Latin letters can imitate Latin ones (for example Cyrillic "а" for "a").');
  else if (host.split('.').some((l) => l.startsWith('xn--'))) add('punycode', 10, 'Encoded international domain (xn--)', 'Check that the decoded name is what you expect.');
  if (!isIp && host.split('.').length - domain.split('.').length >= 3) add('subdomains', 10, 'Many nested subdomains', 'Long subdomain chains are used to push the real domain out of view.');
  if (raw.length > 150) add('length', 12, 'Very long link', `${raw.length} characters; long links can bury the real destination.`);
  else if (raw.length > 75) add('length', 5, 'Long link', `${raw.length} characters.`);
  if ((sld.match(/-/g) || []).length >= 3) add('hyphens', 8, 'Many hyphens in the domain', 'Domains like "secure-login-account-update" are typical of phishing.');
  if (!isIp && RISKY_TLDS.has(tld)) add('tld', 12, `Domain ending ".${tld}" is often abused`, 'Cheap or free endings are over-represented in phishing campaigns.');
  if (SHORTENERS.has(domain)) add('shortener', 15, 'Link shortener', 'The final destination is hidden until you open it.');
  if (u.port) add('port', 8, `Unusual port ${u.port}`, 'Normal websites use the default web ports.');
  if ((raw.match(/%[0-9a-f]{2}/gi) || []).length >= 4) add('encoding', 6, 'Heavy percent-encoding', 'Encoded characters can disguise what the link contains.');
  if (/[?&](url|redirect|redirect_uri|next|continue|dest|target|goto|return)=https?(:|%3a)/i.test(u.search)) add('redirect-param', 12, 'Link forwards you to another site', 'A parameter in the address contains a second web address.');

  const text = (u.hostname + u.pathname + u.search).toLowerCase();
  const hits = KEYWORDS.filter((k) => text.includes(k));
  if (hits.length >= 3) add('keywords', 15, 'Several pressure words in the link', `Found: ${hits.join(', ')}.`);
  else if (hits.length) add('keywords', 5, 'Sensitive word in the link', `Found: ${hits.join(', ')}.`);

  if (!isIp && !OFFICIAL.has(domain)) {
    const brand = BRANDS.find((b) => host.includes(b) && sld !== b);
    const twin = BRANDS.find((b) => sld !== b && ((b.length >= 5 && lev(sld, b) <= 2) || deLeet(sld) === b));
    if (brand) add('brand', 30, `Uses the name "${brand}" on an unrelated domain`, `The real domain is "${domain}", which is not operated by ${brand}.`);
    else if (twin) add('lookalike', 30, `Domain imitates "${twin}"`, `"${sld}" is one or two characters away from "${twin}".`);
  }
  return { url: u.href, host, domain, isIp, findings };
}

const VERDICTS = {
  low: { label: 'Low risk', advice: 'No strong warning signs in the address or its records. Still be careful with anything that asks for passwords or payments.' },
  medium: { label: 'Suspicious', advice: 'Several warning signs. Do not enter personal details; confirm the address through an official app or website.' },
  high: { label: 'Likely phishing', advice: 'This closely matches known phishing patterns. Avoid opening it, and never sign in or pay through it.' },
  critical: { label: 'Dangerous', advice: 'Strong indicators of a scam or malicious payload. Do not open it. Report it if it came from a message or poster.' },
};

export function scoreFindings(findings) {
  const score = Math.min(100, findings.reduce((s, f) => s + f.points, 0));
  const level = score >= 70 ? 'critical' : score >= 45 ? 'high' : score >= 20 ? 'medium' : 'low';
  return { score, level, ...VERDICTS[level] };
}
