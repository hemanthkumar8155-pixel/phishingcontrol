// QR decoding (jsQR, loaded globally in index.html) and payload classification.
import { finding } from './analyzer.js';

const decode = (img) => window.jsQR(img.data, img.width, img.height, { inversionAttempts: 'attemptBoth' })?.data ?? null;

export async function decodeFile(file) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * scale);
  c.height = Math.round(bmp.height * scale);
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  return decode(ctx.getImageData(0, 0, c.width, c.height));
}

export async function startCamera(video, onText) {
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
  video.srcObject = stream;
  await video.play();
  video.hidden = false;
  const c = document.createElement('canvas');
  const ctx = c.getContext('2d', { willReadFrequently: true });
  let on = true;
  const stop = () => { on = false; stream.getTracks().forEach((t) => t.stop()); video.hidden = true; };
  const tick = () => {
    if (!on) return;
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      c.width = video.videoWidth;
      c.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);
      const text = decode(ctx.getImageData(0, 0, c.width, c.height));
      if (text) { stop(); onText(text); return; }
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
  return stop;
}

// QR codes carry more than web links. Classify the payload and flag risky non-URL types.
export function classifyPayload(text) {
  const t = text.trim();
  if (/^https?:\/\//i.test(t)) return { kind: 'web link', url: t, findings: [] };
  if (/^javascript:/i.test(t)) return { kind: 'javascript', findings: [finding('qr-js', 80, 'QR code contains a script', 'Opening it could run code in your browser. Do not open it.')] };
  if (/^data:/i.test(t)) return { kind: 'data URI', findings: [finding('qr-data', 70, 'QR code contains embedded content', 'Data links can render a fake page without any server.')] };
  if (/^upi:\/\//i.test(t)) {
    let p = new URLSearchParams();
    try { p = new URL(t).searchParams; } catch { /* keep empty */ }
    const who = `${p.get('pn') || 'unknown name'} <${p.get('pa') || 'unknown id'}>`;
    return { kind: 'UPI payment', findings: [finding('qr-upi', 20, 'This QR code requests a payment', `It would pay ${who}${p.get('am') ? ` ₹${p.get('am')}` : ''}. Check the name matches. You never enter a UPI PIN to receive money.`)] };
  }
  if (/^wifi:/i.test(t)) return { kind: 'Wi-Fi login', findings: [finding('qr-wifi', 15, 'QR code joins a Wi-Fi network', 'Only join networks you trust; a rogue network can watch your traffic.')] };
  if (/^(mailto|tel|sms|smsto):/i.test(t)) return { kind: 'phone or mail action', findings: [finding('qr-action', 10, 'QR code starts a call, text or email', `It will prepare: ${t.slice(0, 80)}`)] };
  if (/^(?:[a-z0-9-]+\.)+[a-z]{2,}(?:[:/?#].*)?$/i.test(t)) return { kind: 'web link (no scheme)', url: `https://${t}`, findings: [] };
  return { kind: 'plain text', findings: [finding('qr-text', 0, 'Plain text, no link', t.slice(0, 120))] };
}
