import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeUrl, scoreFindings, registrableDomain } from '../docs/js/analyzer.js';
import { classifyPayload } from '../docs/js/qr.js';

const ids = (url) => analyzeUrl(url).findings.map((f) => f.id);

test('registrableDomain handles multi-part endings', () => {
  assert.equal(registrableDomain('a.b.example.co.uk'), 'example.co.uk');
  assert.equal(registrableDomain('www.example.com'), 'example.com');
});

test('ordinary official link scores low', () => {
  const a = analyzeUrl('https://www.google.com/search?q=weather');
  assert.equal(a.findings.length, 0);
  assert.equal(scoreFindings(a.findings).level, 'low');
});

test('brand on an unrelated domain is flagged as high risk', () => {
  const a = analyzeUrl('http://paypal.com.secure-login.tk/verify');
  assert.ok(a.findings.some((f) => f.id === 'brand'));
  assert.ok(scoreFindings(a.findings).score >= 45);
});

test('look-alike domain and hidden host are detected', () => {
  assert.ok(ids('https://paypa1.com').includes('lookalike'));
  const hidden = ids('http://192.0.2.10@bit.ly/kyc-update');
  assert.ok(hidden.includes('userinfo') && hidden.includes('shortener'));
});

test('QR payload classification', () => {
  assert.equal(classifyPayload('javascript:alert(1)').findings[0].points, 80);
  const upi = classifyPayload('upi://pay?pa=a@b&pn=Shop&am=10');
  assert.equal(upi.kind, 'UPI payment');
  assert.ok(upi.findings[0].detail.includes('Shop'));
  assert.equal(classifyPayload('example.com/x').url, 'https://example.com/x');
});
